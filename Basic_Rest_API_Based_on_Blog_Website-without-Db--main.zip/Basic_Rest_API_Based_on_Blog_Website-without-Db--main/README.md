# Basic_Rest_API_Based_on_Blog_Website-without-Db-
a very basic rest API based on a blog website (without database) which can perform all the CRUD operation
